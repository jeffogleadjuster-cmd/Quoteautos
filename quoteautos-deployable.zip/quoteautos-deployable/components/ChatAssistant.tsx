"use client";

import { useEffect, useMemo, useState } from "react";

type ChatAssistantProps = {
  page: "home" | "quote" | "results" | "crm";
  step?: number;
};

export function ChatAssistant({ page, step = 1 }: ChatAssistantProps) {
  const [open, setOpen] = useState(true);
  const [nudge, setNudge] = useState(false);

  const message = useMemo(() => {
    if (page === "home") return "Need help getting your quote? It only takes about 2 minutes.";
    if (page === "results") return "Nice job. Review your quote path, then decide whether you want to check bundle savings too.";
    if (page === "crm") return "This private staff area tracks quote status, fallback routing, and follow-up campaigns.";
    if (step === 1) return "Start with the garaging address. That helps match the quote to the right market.";
    if (step === 2) return "These driver answers help decide whether the request fits the main rater or fallback markets.";
    if (step === 3) return "Vehicle details affect pricing, carrier eligibility, and market routing.";
    if (step === 4) return "Driving history is one of the biggest quote factors, so answer this carefully.";
    return "Almost done. Fill in the contact step so the quote request can be saved and followed up properly.";
  }, [page, step]);

  useEffect(() => {
    setNudge(false);
    if (page !== "quote") return;
    const timer = setTimeout(() => setNudge(true), 12000);
    return () => clearTimeout(timer);
  }, [page, step]);

  return (
    <div className="chatbot">
      {open && (
        <div className="chat-window">
          <div className="chat-head">
            <strong>Quote Helper</strong>
            <button className="btn btn-light" style={{ padding: "8px 12px", borderRadius: 12 }} onClick={() => setOpen(false)}>
              Hide
            </button>
          </div>
          <div className="chat-body">
            <div className="chat-bubble">{message}</div>
            {nudge && <div className="chat-bubble" style={{ marginTop: 10 }}>Still there? You’re closer than you think. Finish this step and keep your quote moving.</div>}
          </div>
        </div>
      )}
      {!open && (
        <button className="btn btn-primary chat-toggle" onClick={() => setOpen(true)}>
          Need help?
        </button>
      )}
    </div>
  );
}
