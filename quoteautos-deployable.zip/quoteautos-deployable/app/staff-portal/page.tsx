"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ChatAssistant } from "@/components/ChatAssistant";

type RecordItem = {
  id?: string;
  created_at?: string;
  applicant: string;
  email: string;
  phone: string;
  zip: string;
  vehicle: string;
  path: string;
  status: string;
  assigned_to: string;
  notes: string;
  homeowner: string;
  insured: string;
  drip: string;
};

export default function StaffPortalPage() {
  const [access, setAccess] = useState(false);
  const [code, setCode] = useState("");
  const [records, setRecords] = useState<RecordItem[]>([]);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    if (!access) return;
    fetch("/api/quotes", { headers: { "x-admin-code": code } })
      .then((r) => r.json())
      .then((data) => setRecords(data.records || []));
  }, [access, code]);

  const visible = useMemo(() => filter === "all" ? records : records.filter((r) => r.status === filter), [records, filter]);

  if (!access) {
    return (
      <div className="page-shell">
        <header className="header"><div className="container header-inner"><div className="brand"><span className="brand-red">Quote</span>Autos</div><Link href="/" className="btn btn-light">View Site</Link></div></header>
        <main className="section">
          <div className="container" style={{ maxWidth: 680 }}>
            <div className="panel-white">
              <div className="small-label">Private CRM</div>
              <h1 style={{ fontSize: 42, marginTop: 12 }}>Staff-only access</h1>
              <p className="lead">Enter your staff access code to open the quote pipeline dashboard. Change this code in your environment variables after deployment.</p>
              <label className="field-label">Staff access code</label>
              <input className="input" value={code} onChange={(e) => setCode(e.target.value)} placeholder="Enter CRM code" />
              <button className="btn btn-primary" style={{ marginTop: 16 }} onClick={() => setAccess(code.length > 0)}>Open CRM</button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="page-shell">
      <header className="header"><div className="container header-inner"><div className="brand"><span className="brand-red">Quote</span>Autos</div><div className="nav"><Link href="/" className="btn btn-light">View Site</Link></div></div></header>
      <main className="section">
        <div className="container">
          <div className="panel-white">
            <div className="small-label">Private CRM</div>
            <h1 style={{ fontSize: 46, marginTop: 12 }}>Quote Pipeline Dashboard</h1>
            <p className="lead">Track submitted quote requests, see which path they took, and manage simple trickle marketing campaigns.</p>
          </div>

          <div className="stats-grid" style={{ marginTop: 22 }}>
            {[
              ["Total Records", records.length],
              ["Quoted", records.filter((r) => r.status === "Quoted").length],
              ["Needs Follow-Up", records.filter((r) => r.status === "Needs Follow-Up").length],
              ["Needs Review", records.filter((r) => r.status === "Needs Review").length],
            ].map(([label, value]) => (
              <div key={label} className="stat-card"><div className="stat-big">{value}</div><div style={{ color: '#64748b', marginTop: 8 }}>{label}</div></div>
            ))}
          </div>

          <div className="crm-grid" style={{ marginTop: 22 }}>
            <div className="panel-white">
              <div className="filter-bar">
                <div>
                  <h2 style={{ margin: 0 }}>Quote Records</h2>
                  <p style={{ color: '#64748b', marginTop: 6 }}>Track standard, fallback, and manual-review quote requests.</p>
                </div>
                <select className="select" style={{ maxWidth: 240 }} value={filter} onChange={(e) => setFilter(e.target.value)}>
                  <option value="all">All statuses</option>
                  <option value="Quoted">Quoted</option>
                  <option value="Needs Follow-Up">Needs Follow-Up</option>
                  <option value="Needs Review">Needs Review</option>
                </select>
              </div>

              <div className="crm-list" style={{ marginTop: 18 }}>
                {visible.map((record, index) => (
                  <div key={record.id || index} className="crm-card">
                    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
                      <div>
                        <div className="small-label" style={{ color: '#64748b' }}>{record.id || 'record'}</div>
                        <h3 style={{ margin: '12px 0 0', fontSize: 28 }}>{record.applicant}</h3>
                        <div style={{ marginTop: 6, color: '#64748b' }}>{record.created_at || 'Just now'}</div>
                      </div>
                      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                        <span className="mini-pill" style={{ background: '#f1f5f9', color: '#0f172a', borderColor: '#e2e8f0' }}>{record.path}</span>
                        <span className="mini-pill" style={{ background: '#fef2f2', color: '#b91c1c', borderColor: '#fecaca' }}>{record.status}</span>
                      </div>
                    </div>
                    <div className="row-2" style={{ marginTop: 16 }}>
                      <Tile label="Email" value={record.email} />
                      <Tile label="Phone" value={record.phone} />
                      <Tile label="ZIP" value={record.zip} />
                      <Tile label="Vehicle" value={record.vehicle} />
                      <Tile label="Assigned To" value={record.assigned_to} />
                      <Tile label="Campaign" value={record.drip} />
                    </div>
                    <div className="info-card" style={{ marginTop: 14, padding: 14 }}>{record.notes}</div>
                  </div>
                ))}
                {visible.length === 0 && <div className="info-card" style={{ padding: 16 }}>No records found yet.</div>}
              </div>
            </div>

            <div>
              <div className="panel-white">
                <h2 style={{ marginTop: 0 }}>Trickle Marketing</h2>
                <p style={{ color: '#64748b', lineHeight: 1.7 }}>These starter campaigns are built for quote completion and follow-up, not open-ended chatbot conversations.</p>
                <div className="crm-list" style={{ marginTop: 14 }}>
                  {[
                    ["Quote Reminder", "Trigger: quote shown, no bind", "Email + SMS"],
                    ["Fallback Follow-Up", "Trigger: fallback market shown", "Email"],
                    ["Manual Review Update", "Trigger: manual review queue", "Email + call task"],
                    ["Bundle Offer", "Trigger: homeowner after auto quote", "Email"],
                  ].map(([name, trigger, channel]) => (
                    <div key={name} className="info-card" style={{ padding: 16 }}>
                      <strong>{name}</strong>
                      <div style={{ marginTop: 8, color: '#64748b' }}>{trigger}</div>
                      <div style={{ color: '#64748b' }}>Channel: {channel}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="dark-panel" style={{ marginTop: 18 }}>
                <h2 style={{ color: 'white', marginTop: 0 }}>Suggested sequence</h2>
                <div className="form-grid">
                  {[
                    "Day 0: quote confirmation email",
                    "Day 1: saved quote reminder",
                    "Day 3: fallback or manual-review update",
                    "Day 5: homeowners get bundle savings offer",
                  ].map((item) => <div key={item} className="mini-pill">{item}</div>)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <ChatAssistant page="crm" />
    </div>
  );
}

function Tile({ label, value }: { label: string; value: string }) {
  return (
    <div className="info-card" style={{ padding: 14 }}>
      <div className="small-label" style={{ color: '#64748b' }}>{label}</div>
      <div style={{ fontWeight: 700, marginTop: 6 }}>{value}</div>
    </div>
  );
}
