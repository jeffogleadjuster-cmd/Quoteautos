import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "QuoteAutos",
  description: "Compare auto insurance quotes in minutes.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
