import { NextRequest, NextResponse } from "next/server";
import { getSupabaseAdmin } from "@/lib/supabase";

const fallbackRecords = [
  {
    id: "QA-1001",
    created_at: "2026-04-18 10:12 AM",
    applicant: "Jamie Parker",
    email: "jamie@example.com",
    phone: "(555) 210-9988",
    zip: "75001",
    vehicle: "2022 Toyota Camry",
    path: "Primary",
    status: "Quoted",
    assigned_to: "Unassigned",
    notes: "Good fit for standard market.",
    homeowner: "Yes",
    insured: "Yes",
    drip: "Quote Reminder",
  },
  {
    id: "QA-1002",
    created_at: "2026-04-18 11:04 AM",
    applicant: "Alex Turner",
    email: "alex@example.com",
    phone: "(555) 660-1234",
    zip: "60614",
    vehicle: "2018 Nissan Altima",
    path: "Fallback",
    status: "Needs Follow-Up",
    assigned_to: "CSR Queue",
    notes: "Primary path failed, fallback quote shown.",
    homeowner: "No",
    insured: "No",
    drip: "Fallback Follow-Up",
  },
];

export async function POST(req: NextRequest) {
  const body = await req.json();
  const supabase = getSupabaseAdmin();
  if (!supabase) {
    return NextResponse.json({ ok: true, mode: "demo" });
  }

  const payload = {
    applicant: body.applicant,
    email: body.email,
    phone: body.phone,
    zip: body.zip,
    vehicle: body.vehicle,
    path: body.path,
    status: body.status,
    assigned_to: body.assigned_to,
    notes: body.notes,
    homeowner: body.homeowner,
    insured: body.insured,
    drip: body.drip,
    form_snapshot: body.form_snapshot ?? null,
    result_snapshot: body.result_snapshot ?? null,
  };

  const { error } = await supabase.from("quotes").insert(payload);
  if (error) {
    return NextResponse.json({ ok: false, error: error.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true, mode: "live" });
}

export async function GET(req: NextRequest) {
  const adminCode = req.headers.get("x-admin-code");
  if (!adminCode || adminCode !== (process.env.CRM_ACCESS_CODE || "quoteautoscrm")) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const supabase = getSupabaseAdmin();
  if (!supabase) {
    return NextResponse.json({ ok: true, records: fallbackRecords, mode: "demo" });
  }

  const { data, error } = await supabase
    .from("quotes")
    .select("id, created_at, applicant, email, phone, zip, vehicle, path, status, assigned_to, notes, homeowner, insured, drip")
    .order("created_at", { ascending: false });

  if (error) {
    return NextResponse.json({ ok: false, error: error.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true, records: data ?? [], mode: "live" });
}
