import Link from "next/link";
import { ChatAssistant } from "@/components/ChatAssistant";

export default function HomePage() {
  return (
    <div className="page-shell">
      <header className="header">
        <div className="container header-inner">
          <div className="brand"><span className="brand-red">Quote</span>Autos</div>
          <nav className="nav">
            <a className="nav-link" href="#how-it-works">How It Works</a>
            <a className="nav-link" href="#why-quoteautos">Why QuoteAutos</a>
            <a className="nav-link" href="#faq">FAQ</a>
            <Link href="/quote" className="btn btn-primary">Check My Rates</Link>
          </nav>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="container hero-grid">
            <div>
              <div className="badge">Real quote flow with fallback market routing</div>
              <h1>Compare Auto Insurance Quotes in Minutes</h1>
              <p>
                Collect the quote details once, try the main rating path first, then fall back to additional markets when standard quotes are unavailable.
              </p>
              <div className="hero-list">
                {[
                  "Primary rater first",
                  "Fallback market logic built in",
                  "Manual review path for hard cases",
                  "Bundle prompt after quoting",
                ].map((item) => (
                  <div key={item} className="mini-pill">{item}</div>
                ))}
              </div>
            </div>

            <div className="hero-card">
              <div className="small-label">Start Your Quote</div>
              <h2 style={{ fontSize: 34, margin: '10px 0 0' }}>See Rates Near You</h2>
              <p style={{ color: '#64748b', fontSize: 15, lineHeight: 1.6 }}>
                Start with your ZIP code, answer a few short questions, and move into the quote path.
              </p>
              <label className="field-label">ZIP Code</label>
              <input className="input" placeholder="Enter ZIP code" defaultValue="75001" />
              <Link href="/quote" className="btn btn-primary" style={{ display: 'block', textAlign: 'center', marginTop: 14 }}>
                Check My Rates
              </Link>
              <p style={{ color: '#64748b', fontSize: 12, lineHeight: 1.6 }}>
                By clicking “Check My Rates,” you agree to the site terms and privacy policy and consent to contact regarding your quote request.
              </p>
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container stats-grid">
            {[
              ["Quote path", "Primary + Fallback"],
              ["Average form time", "~2 min"],
              ["Questions to complete", "5 steps"],
              ["Manual rescue", "Included"],
            ].map(([label, value]) => (
              <div key={label} className="stat-card">
                <div className="stat-big">{value}</div>
                <div style={{ color: '#64748b', marginTop: 8 }}>{label}</div>
              </div>
            ))}
          </div>
        </section>

        <section className="section" id="how-it-works">
          <div className="container">
            <div className="small-label">How It Works</div>
            <h2>A quote flow built for real-world market gaps</h2>
            <p className="lead">Capture the quote request once, try the standard path first, and avoid dead ends by rescuing failed quotes with fallback markets and manual review.</p>
            <div className="feature-grid">
              {[
                ["Collect data", "Capture address, driver, vehicle, coverage, and contact information in one short flow."],
                ["Run quote logic", "Try the primary rater first, then route to fallback markets if standard quotes fail."],
                ["Rescue hard cases", "If neither path returns instant quotes, send the request to manual review instead of losing the customer."],
              ].map(([title, text], index) => (
                <div key={title} className="feature-card">
                  <div className="small-label">Step {index + 1}</div>
                  <h3 style={{ fontSize: 28, margin: '12px 0' }}>{title}</h3>
                  <p style={{ color: '#64748b', lineHeight: 1.7 }}>{text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="section" id="why-quoteautos" style={{ background: '#fff' }}>
          <div className="container two-col">
            <div className="dark-panel">
              <div className="small-label">Why QuoteAutos</div>
              <h2 style={{ color: 'white' }}>Designed to feel fast, clear, and trustworthy</h2>
              <div className="hero-list" style={{ gridTemplateColumns: '1fr 1fr' }}>
                {[
                  "Short multi-step form",
                  "Mobile-friendly design",
                  "Primary + fallback routing",
                  "Built-in follow-up CRM",
                ].map((item) => (
                  <div key={item} className="mini-pill">{item}</div>
                ))}
              </div>
            </div>
            <div className="light-panel">
              <div className="small-label" style={{ color: '#64748b' }}>What happens next</div>
              <h3 style={{ fontSize: 34, marginTop: 12 }}>You control the quote journey</h3>
              <div className="form-grid" style={{ marginTop: 22 }}>
                {[
                  "See standard market quotes first",
                  "Rescue failed quotes with fallback markets",
                  "Move hard cases to manual review",
                  "Prompt for home + auto bundle after quoting",
                ].map((item) => (
                  <div key={item} className="info-card" style={{ padding: 16 }}>{item}</div>
                ))}
              </div>
              <Link href="/quote" className="btn btn-primary" style={{ display: 'inline-block', marginTop: 22 }}>Start My Quote</Link>
            </div>
          </div>
        </section>

        <section className="section" id="faq">
          <div className="container">
            <div className="small-label">FAQ</div>
            <h2>Common questions</h2>
            <div className="cards-grid" style={{ marginTop: 24 }}>
              {[
                ["How long does it take?", "Most people can complete the form in about two minutes."],
                ["What if the rater returns nothing?", "The site can route to fallback markets or manual review instead of dead-ending."],
                ["Can I ask about bundling?", "Yes. The site prompts for home + auto only after the auto quote path has already been attempted."],
              ].map(([q, a]) => (
                <div key={q} className="faq-card" style={{ padding: 22 }}>
                  <h3 style={{ marginTop: 0 }}>{q}</h3>
                  <p style={{ color: '#64748b', lineHeight: 1.7 }}>{a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="container footer-grid">
          <div>
            <div className="brand"><span className="brand-red">Quote</span>Autos</div>
            <p style={{ maxWidth: 760, color: '#94a3b8', lineHeight: 1.7 }}>
              QuoteAutos is built as a quote-first workflow with primary rating, fallback market handling, and manual review when instant quotes are unavailable.
            </p>
          </div>
          <div className="cards-grid" style={{ gridTemplateColumns: 'repeat(3,minmax(0,1fr))', gap: 28 }}>
            <div>
              <strong style={{ color: 'white' }}>Company</strong>
              <div style={{ marginTop: 12, color: '#94a3b8' }}>About</div>
              <div style={{ marginTop: 8, color: '#94a3b8' }}>Contact</div>
            </div>
            <div>
              <strong style={{ color: 'white' }}>Legal</strong>
              <div style={{ marginTop: 12, color: '#94a3b8' }}>Privacy</div>
              <div style={{ marginTop: 8, color: '#94a3b8' }}>Terms</div>
            </div>
            <div>
              <strong style={{ color: 'white' }}>Staff</strong>
              <div style={{ marginTop: 12, color: '#94a3b8' }}>Hidden CRM route in README</div>
            </div>
          </div>
        </div>
        <div className="container footer-bottom">
          <div style={{ fontSize: 12, color: '#64748b' }}>Built to deploy on Vercel with Supabase for CRM storage.</div>
        </div>
      </footer>

      <ChatAssistant page="home" />
    </div>
  );
}
