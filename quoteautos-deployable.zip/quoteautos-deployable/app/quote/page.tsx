"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { ChatAssistant } from "@/components/ChatAssistant";

type FormState = {
  zip: string;
  address: string;
  city: string;
  state: string;
  dob: string;
  homeowner: string;
  insured: string;
  priorCarrier: string;
  year: string;
  make: string;
  model: string;
  mileage: string;
  coverage: string;
  accidents: string;
  tickets: string;
  first: string;
  last: string;
  email: string;
  phone: string;
};

type QuoteResult = {
  status: "quoted_primary" | "quoted_fallback" | "manual_review";
  primaryQuotes: { carrier: string; premium: string; type: string }[];
  fallbackQuotes: { carrier: string; premium: string; type: string }[];
};

const initialState: FormState = {
  zip: "",
  address: "",
  city: "",
  state: "",
  dob: "",
  homeowner: "",
  insured: "",
  priorCarrier: "",
  year: "",
  make: "",
  model: "",
  mileage: "",
  coverage: "",
  accidents: "",
  tickets: "",
  first: "",
  last: "",
  email: "",
  phone: "",
};

export default function QuotePage() {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState<FormState>(initialState);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const progress = useMemo(() => step * 20, [step]);

  const requiredByStep: Record<number, (keyof FormState)[]> = {
    1: ["zip", "address", "city", "state"],
    2: ["dob", "homeowner", "insured", "priorCarrier"],
    3: ["year", "make", "model", "mileage"],
    4: ["coverage", "accidents", "tickets"],
    5: ["first", "last", "email", "phone"],
  };

  const setField = (key: keyof FormState, value: string) => setForm((f) => ({ ...f, [key]: value }));

  const validate = () => {
    for (const key of requiredByStep[step]) {
      if (!String(form[key]).trim()) {
        setError("Please complete all fields before continuing.");
        return false;
      }
    }
    if (step === 1 && !/^\d{5}$/.test(form.zip)) {
      setError("Please enter a valid 5-digit ZIP code.");
      return false;
    }
    if (step === 5) {
      const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email);
      const phoneOk = form.phone.replace(/\D/g, "").length >= 10;
      if (!emailOk) {
        setError("Please enter a valid email address.");
        return false;
      }
      if (!phoneOk) {
        setError("Please enter a valid phone number.");
        return false;
      }
    }
    setError("");
    return true;
  };

  const next = () => validate() && setStep((s) => s + 1);
  const back = () => { setError(""); setStep((s) => Math.max(1, s - 1)); };

  const simulateQuoteRouting = (): QuoteResult => {
    const accidentsNum = Number(form.accidents || 0);
    const ticketsNum = Number(form.tickets || 0);
    const uninsured = form.insured === "No";
    const highMileage = Number(form.mileage || 0) > 18000;
    const primaryBlocked = accidentsNum >= 2 || ticketsNum >= 2 || uninsured;
    const fallbackBlocked = accidentsNum >= 3 || ticketsNum >= 3 || (uninsured && highMileage);

    if (!primaryBlocked) {
      return {
        status: "quoted_primary",
        primaryQuotes: [
          { carrier: "Harbor Mutual", premium: "$128/mo", type: "Preferred" },
          { carrier: "Summit Casualty", premium: "$142/mo", type: "Standard" },
          { carrier: "Pioneer Auto", premium: "$156/mo", type: "Value" },
        ],
        fallbackQuotes: [],
      };
    }

    if (!fallbackBlocked) {
      return {
        status: "quoted_fallback",
        primaryQuotes: [],
        fallbackQuotes: [
          { carrier: "Coastal Specialty", premium: "$188/mo", type: "Fallback Market" },
          { carrier: "Northline Assurance", premium: "$214/mo", type: "Fallback Market" },
        ],
      };
    }

    return { status: "manual_review", primaryQuotes: [], fallbackQuotes: [] };
  };

  const submit = async () => {
    if (!validate()) return;
    setLoading(true);
    const result = simulateQuoteRouting();
    const payload = {
      applicant: `${form.first} ${form.last}`.trim(),
      email: form.email,
      phone: form.phone,
      zip: form.zip,
      vehicle: `${form.year} ${form.make} ${form.model}`.trim(),
      path: result.status === "quoted_primary" ? "Primary" : result.status === "quoted_fallback" ? "Fallback" : "Manual Review",
      status: result.status === "manual_review" ? "Needs Review" : result.status === "quoted_fallback" ? "Needs Follow-Up" : "Quoted",
      assigned_to: result.status === "manual_review" ? "Agent Queue" : result.status === "quoted_fallback" ? "CSR Queue" : "Unassigned",
      notes: result.status === "quoted_primary" ? "Primary market quotes returned." : result.status === "quoted_fallback" ? "Fallback market quotes returned." : "No instant quotes. Route to manual team.",
      homeowner: form.homeowner,
      insured: form.insured,
      drip: result.status === "manual_review" ? "Manual Review Update" : result.status === "quoted_fallback" ? "Fallback Follow-Up" : "Quote Reminder",
      form_snapshot: form,
      result_snapshot: result,
    };

    await fetch("/api/quotes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (typeof window !== "undefined") {
      sessionStorage.setItem("quoteautos_last_result", JSON.stringify({ form, result }));
    }
    router.push("/results");
  };

  return (
    <div className="page-shell">
      <header className="header">
        <div className="container header-inner">
          <div className="brand"><span className="brand-red">Quote</span>Autos</div>
          <div className="nav">
            <Link href="/" className="btn btn-light">Back Home</Link>
          </div>
        </div>
      </header>

      <main className="funnel-shell">
        <div className="container funnel-grid">
          <div className="dark-panel">
            <div className="small-label">QuoteAutos</div>
            <h1 style={{ color: 'white', fontSize: 46, lineHeight: 1.08, marginTop: 12 }}>Quote first. Fallback second. Manual review if needed.</h1>
            <p style={{ color: '#cbd5e1', lineHeight: 1.7 }}>
              This form captures everything needed to try the main quote path first, then rescue tough cases with fallback markets or manual review.
            </p>
            <div className="progress"><div className="progress-inner" style={{ width: `${progress}%` }} /></div>
            <div style={{ marginTop: 10, color: '#cbd5e1', fontWeight: 700 }}>Step {step} of 5</div>
            <div className="form-grid" style={{ marginTop: 28 }}>
              {[
                "Required fields on every step",
                "Primary rater attempt first",
                "Fallback market path built in",
                "Bundle prompt after auto quote attempt",
              ].map((item) => <div key={item} className="mini-pill">{item}</div>)}
            </div>
          </div>

          <div className="panel-white">
            <div className="small-label">Secure Quote Form</div>
            <h2 style={{ fontSize: 36, marginTop: 12 }}>Step {step} of 5</h2>
            {error && <div className="error-box">{error}</div>}

            {step === 1 && (
              <Section title="Where is the vehicle garaged?" subtitle="Start with the full location details.">
                <Field label="ZIP Code"><input className="input" value={form.zip} onChange={(e) => setField("zip", e.target.value)} placeholder="75001" /></Field>
                <Field label="Street Address"><input className="input" value={form.address} onChange={(e) => setField("address", e.target.value)} placeholder="123 Main St" /></Field>
                <div className="row-2">
                  <Field label="City"><input className="input" value={form.city} onChange={(e) => setField("city", e.target.value)} placeholder="Dallas" /></Field>
                  <Field label="State"><input className="input" value={form.state} onChange={(e) => setField("state", e.target.value)} placeholder="TX" /></Field>
                </div>
              </Section>
            )}

            {step === 2 && (
              <Section title="Tell us about the driver" subtitle="These answers help decide which markets to try first.">
                <Field label="Date of Birth"><input className="input" value={form.dob} onChange={(e) => setField("dob", e.target.value)} placeholder="MM/DD/YYYY" /></Field>
                <div className="row-2">
                  <Field label="Homeowner">
                    <select className="select" value={form.homeowner} onChange={(e) => setField("homeowner", e.target.value)}>
                      <option value="">Select one</option><option>Yes</option><option>No</option>
                    </select>
                  </Field>
                  <Field label="Currently Insured">
                    <select className="select" value={form.insured} onChange={(e) => setField("insured", e.target.value)}>
                      <option value="">Select one</option><option>Yes</option><option>No</option>
                    </select>
                  </Field>
                </div>
                <Field label="Prior Carrier"><input className="input" value={form.priorCarrier} onChange={(e) => setField("priorCarrier", e.target.value)} placeholder="Progressive, GEICO, None, etc." /></Field>
              </Section>
            )}

            {step === 3 && (
              <Section title="Vehicle details" subtitle="Basic vehicle data for the quote request.">
                <div className="row-3">
                  <Field label="Vehicle Year"><input className="input" value={form.year} onChange={(e) => setField("year", e.target.value)} placeholder="2022" /></Field>
                  <Field label="Make"><input className="input" value={form.make} onChange={(e) => setField("make", e.target.value)} placeholder="Toyota" /></Field>
                  <Field label="Model"><input className="input" value={form.model} onChange={(e) => setField("model", e.target.value)} placeholder="Camry" /></Field>
                </div>
                <Field label="Annual Mileage"><input className="input" value={form.mileage} onChange={(e) => setField("mileage", e.target.value)} placeholder="12000" /></Field>
              </Section>
            )}

            {step === 4 && (
              <Section title="Coverage and driving history" subtitle="These answers decide whether the request stays standard or needs fallback handling.">
                <Field label="Coverage Type">
                  <select className="select" value={form.coverage} onChange={(e) => setField("coverage", e.target.value)}>
                    <option value="">Select one</option><option>Full Coverage</option><option>Liability Only</option>
                  </select>
                </Field>
                <div className="row-2">
                  <Field label="Accidents in Last 3 Years">
                    <select className="select" value={form.accidents} onChange={(e) => setField("accidents", e.target.value)}>
                      <option value="">Select one</option><option>0</option><option>1</option><option>2</option><option>3</option>
                    </select>
                  </Field>
                  <Field label="Tickets in Last 3 Years">
                    <select className="select" value={form.tickets} onChange={(e) => setField("tickets", e.target.value)}>
                      <option value="">Select one</option><option>0</option><option>1</option><option>2</option><option>3</option>
                    </select>
                  </Field>
                </div>
              </Section>
            )}

            {step === 5 && (
              <Section title="Where should we send your quote results?" subtitle="Complete the contact details to finish the quote request.">
                <div className="row-2">
                  <Field label="First Name"><input className="input" value={form.first} onChange={(e) => setField("first", e.target.value)} placeholder="John" /></Field>
                  <Field label="Last Name"><input className="input" value={form.last} onChange={(e) => setField("last", e.target.value)} placeholder="Smith" /></Field>
                </div>
                <Field label="Email"><input className="input" value={form.email} onChange={(e) => setField("email", e.target.value)} placeholder="john@email.com" /></Field>
                <Field label="Phone"><input className="input" value={form.phone} onChange={(e) => setField("phone", e.target.value)} placeholder="(555) 555-5555" /></Field>
              </Section>
            )}

            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, marginTop: 28, flexWrap: 'wrap' }}>
              <button className="btn btn-light" onClick={back} disabled={step === 1}>Back</button>
              {step < 5 ? (
                <button className="btn btn-primary" onClick={next}>Continue</button>
              ) : (
                <button className="btn btn-green" onClick={submit} disabled={loading}>{loading ? 'Saving...' : 'Quote It'}</button>
              )}
            </div>
          </div>
        </div>
      </main>

      <ChatAssistant page="quote" step={step} />
    </div>
  );
}

function Section({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 style={{ fontSize: 28, marginBottom: 8 }}>{title}</h3>
      <p style={{ color: '#64748b', lineHeight: 1.7 }}>{subtitle}</p>
      <div className="form-grid" style={{ marginTop: 18 }}>{children}</div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label>
      <span className="field-label">{label}</span>
      {children}
    </label>
  );
}
