"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { ChatAssistant } from "@/components/ChatAssistant";

type Saved = {
  form: Record<string, string>;
  result: {
    status: "quoted_primary" | "quoted_fallback" | "manual_review";
    primaryQuotes: { carrier: string; premium: string; type: string }[];
    fallbackQuotes: { carrier: string; premium: string; type: string }[];
  };
};

export default function ResultsPage() {
  const [data, setData] = useState<Saved | null>(null);
  const [bundleChoice, setBundleChoice] = useState<null | boolean>(null);

  useEffect(() => {
    const raw = sessionStorage.getItem("quoteautos_last_result");
    if (raw) setData(JSON.parse(raw));
  }, []);

  const quotes = useMemo(() => {
    if (!data) return [];
    return data.result.primaryQuotes.length ? data.result.primaryQuotes : data.result.fallbackQuotes;
  }, [data]);

  if (!data) {
    return (
      <div className="page-shell">
        <header className="header"><div className="container header-inner"><div className="brand"><span className="brand-red">Quote</span>Autos</div></div></header>
        <main className="section"><div className="container"><h1>No quote session found</h1><Link href="/quote" className="btn btn-primary">Start a Quote</Link></div></main>
      </div>
    );
  }

  const title = data.result.status === "quoted_primary"
    ? "We found standard market quotes"
    : data.result.status === "quoted_fallback"
      ? "We found fallback market options"
      : "We need to review additional markets";

  return (
    <div className="page-shell">
      <header className="header"><div className="container header-inner"><div className="brand"><span className="brand-red">Quote</span>Autos</div><Link href="/quote" className="btn btn-light">New Quote</Link></div></header>
      <main className="section">
        <div className="container panel-white">
          <div className="small-label">Quote Results</div>
          <h1 style={{ fontSize: 48, marginTop: 12 }}>{title}</h1>
          <p className="lead" style={{ maxWidth: 900 }}>
            {data.result.status === "manual_review"
              ? "Neither the primary nor fallback path returned an instant result. This request should be moved into assisted review rather than ending the session."
              : "Review the options below, then decide whether you also want to check home + auto bundle savings."}
          </p>

          {data.result.status !== "manual_review" && (
            <div className="results-grid" style={{ marginTop: 28 }}>
              {quotes.map((quote) => (
                <div key={quote.carrier} className="quote-card">
                  <div className="small-label" style={{ color: '#64748b' }}>{quote.type}</div>
                  <h3 style={{ fontSize: 28, marginTop: 12 }}>{quote.carrier}</h3>
                  <div className="price">{quote.premium}</div>
                  <button className="btn btn-dark" style={{ width: '100%', marginTop: 18 }}>Select Option</button>
                </div>
              ))}
            </div>
          )}

          {data.result.status === "manual_review" && (
            <div className="info-card" style={{ padding: 22, marginTop: 22, background: '#fffbeb', borderColor: '#fde68a' }}>
              <strong style={{ fontSize: 24 }}>Manual review needed</strong>
              <p style={{ color: '#92400e', lineHeight: 1.7 }}>
                Route this request to your non-rater markets or internal team. This page is designed to prevent a dead end and keep the customer in your process.
              </p>
            </div>
          )}

          <div className="dark-panel" style={{ marginTop: 30 }}>
            <div className="small-label">Bundle opportunity</div>
            <h2 style={{ color: 'white' }}>Do you want to quote home + auto too?</h2>
            <p style={{ color: '#cbd5e1', lineHeight: 1.7 }}>
              This prompt appears after the auto quote path has already been attempted, which is the order you asked for.
            </p>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginTop: 18 }}>
              <button className="btn btn-light" onClick={() => setBundleChoice(true)}>Yes, check bundle options</button>
              <button className="btn btn-primary" onClick={() => setBundleChoice(false)}>No, continue with auto only</button>
            </div>
          </div>

          {bundleChoice !== null && (
            <div className="info-card" style={{ padding: 22, marginTop: 22 }}>
              <h3 style={{ fontSize: 28, marginTop: 0 }}>{bundleChoice ? 'Bundle path selected' : 'Continuing with auto only'}</h3>
              <p style={{ color: '#64748b', lineHeight: 1.7 }}>
                {bundleChoice
                  ? 'In production, this is where you would collect a few home details and run your home or bundle market path.'
                  : 'In production, this is where the customer would continue into the selected carrier or assisted quote path.'}
              </p>
              <Link href="/" className="btn btn-primary">Back to homepage</Link>
            </div>
          )}
        </div>
      </main>
      <ChatAssistant page="results" />
    </div>
  );
}
