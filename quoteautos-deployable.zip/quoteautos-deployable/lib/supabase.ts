import { createClient } from "@supabase/supabase-js";

export function getSupabaseAdmin() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return null;
  return createClient(url, key, { auth: { autoRefreshToken: false, persistSession: false } });
}

export type QuoteRecord = {
  id?: string;
  created_at?: string;
  applicant: string;
  email: string;
  phone: string;
  zip: string;
  vehicle: string;
  path: "Primary" | "Fallback" | "Manual Review";
  status: "Quoted" | "Needs Follow-Up" | "Needs Review";
  assigned_to: string;
  notes: string;
  homeowner: string;
  insured: string;
  drip: string;
};
